import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { SwaggerModule, DocumentBuilder } from '@nestjs/swagger';
import { ValidationPipe } from '@nestjs/common';
// import connectDB from "../config/ormconfig";

// Use environment variables
import * as dotenv from 'dotenv'
dotenv.config();

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  app.useGlobalPipes(new ValidationPipe()); // Added this line for DTO validation
  const config = new DocumentBuilder()
  .setTitle('Sadasiba NestJS Project')
  // .setDescription('The cats API description')
  .setVersion('1.0')
  // .addTag('cats')
  .build();
const document = SwaggerModule.createDocument(app, config);
SwaggerModule.setup('api', app, document);
//  console.log(process)
  await app.listen(3000);
}
bootstrap();
