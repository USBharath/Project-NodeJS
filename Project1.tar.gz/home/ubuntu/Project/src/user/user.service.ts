import { Injectable } from '@nestjs/common';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { User } from './entities/user.entity';
import { Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { UserProfile } from 'src/profile/entities/profile.entity';
import { Comment } from 'src/user/entities/comment.entity';

@Injectable()
export class UserService {
  constructor(
    @InjectRepository(User) private userRepository: Repository<User>,
    @InjectRepository(UserProfile) private userProfileRepository: Repository<UserProfile>,
    @InjectRepository(Comment) private commentRepository: Repository<Comment>
  ){}

  create(createUserDto: CreateUserDto) {
  console.log(createUserDto)
  
    let user = this.userRepository.create(createUserDto)
    
    let comment = new Comment()
    comment.message = "saaa"
    comment.user = user
    let comments = this.commentRepository.create(comment)

    console.log(comments)

    // user.comments = [comments]
    // createUserDto.
    // const profile = this.userProfileRepository.create(createUserDto.userProfile)
    // let user = this.userRepository.create(createUserDto)
    // console.log(user)
    // user.userProfile = profile;
    
     this.userRepository.save(user)
     return this.commentRepository.save([comments])
  }

  findAll() {
    return this.userRepository.find({relations:{
      userProfile: true
    }})
  }

  search() {
    return this.userRepository.find({relations:{
      userProfile: true
    }})
  }

  async findOne(id: string) {
    return this.userRepository.findOne({
      where:{id:id},
      relations: ['userProfile']})
    // return await this.userRepository.findOneOrFail( { where: {id: id}})
  }

  update(id: string, updateUserDto: UpdateUserDto) {
    const user = this.userRepository.create(updateUserDto)
    user.id = id;
    return this.userRepository.save(user)
  }

  async remove(id: string) {
    // const user = await this.userRepository.findOne({
    //   where:{id:id},
    //   relations: ['userProfile']
    // })


    // console.log(user)

    return this.userRepository.delete(id)
  }
}
