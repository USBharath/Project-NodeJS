import { Entity, Column, PrimaryGeneratedColumn, BeforeInsert, JoinColumn, OneToOne, ManyToOne } from 'typeorm';
import { User } from '../../user/entities/user.entity';
import * as bcrypt from 'bcrypt';
import { type } from 'os';

@Entity()

export class Comment {
    @PrimaryGeneratedColumn("uuid")
    id: string;

    @Column()
    message: String;

    @ManyToOne((type) => User, user => user.comments, {
        onDelete: 'CASCADE'
    })
    user: User
}