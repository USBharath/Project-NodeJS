import { Entity, Column, PrimaryGeneratedColumn, BeforeInsert, JoinColumn, OneToOne, OneToMany } from 'typeorm';
import { UserProfile } from '../../profile/entities/profile.entity';
import { Comment } from '../../user/entities/comment.entity';
import * as bcrypt from 'bcrypt';

@Entity()

export class User {
    @PrimaryGeneratedColumn("uuid")
    id: string;

    @Column({unique: true})
    email: string;

    @Column({ select: false })
    password: string;
  
    @Column()
    firstName: string;

    @Column()
    lastName: string;

    @Column({ default: true })
    isActive: boolean;

    @OneToMany(() => Comment, comment => comment.user, {cascade: true})
    comments: Comment[]

    @OneToOne(() => UserProfile, { cascade: true, onDelete: 'CASCADE' })
    @JoinColumn()
    userProfile: UserProfile;

    @BeforeInsert()
    async hashPasswordBeforeInsert() {
        this.password = await bcrypt.hash(this.password, 10); // 10 is the number of bcrypt salt rounds
    }

    // @BeforeInsert()
    // generateUser (): void {
    //     // 'this' will refer to our entity
    //     console.log(this.firstName)
    //     if (!this.firstName) {
    //     this.firstName = `${this.firstName}@example.com`;
    //     }
    // }
}
