import { ApiProperty } from '@nestjs/swagger';
import { IsBoolean, IsEmail, IsNotEmpty, IsString } from '@nestjs/class-validator';
import { CreateProfileDto } from '../../profile/dto/create-profile.dto';

export class CreateUserDto {

  @IsString({message : "Email should be string"})
  @IsNotEmpty({message : "Email should not be empty"})
  @IsEmail()
  @ApiProperty({example: "sadasiba@gmail.com"})
  email: string;

  @IsString({message : "Password should be string"})
  @IsNotEmpty({message : "Password should not be empty"})
  @ApiProperty({example: "sadasiba"})
  password: string;

  @IsString({message : "First name should be string"})
  @IsNotEmpty({message : "First name should not be empty"})
  @ApiProperty({example: "sadasiba"})
  firstName: string;

  @IsString({message : "Last name should be string"})
  @IsNotEmpty({message : "Last name should not be empty"})
  @ApiProperty({example: "sahoo"})
  lastName: string;

  @ApiProperty()
  userProfile: CreateProfileDto;

  // @ApiProperty()
  // comments: any[];

  @IsBoolean({message : "User name should be boolean"})
  @ApiProperty({example: true})
  isActive: boolean;
}

