import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString } from '@nestjs/class-validator';

export class SearchUserDto {

  @IsString({message : "User name should be string"})
  @IsNotEmpty({message : "User name should not be empty"})
  @ApiProperty()
  name: string;
}

