import { ApiHideProperty, PartialType } from '@nestjs/swagger';
import { CreateUserDto } from './create-user.dto';

export class UpdateUserDto extends PartialType(CreateUserDto) {
    @ApiHideProperty() // This property will be hidden in the Swagger documentation
    password: string;
}
