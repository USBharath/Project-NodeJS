import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { JenkinsService } from './jenkins.service';
import { CreateJenkinDto } from './dto/create-jenkin.dto';
import { UpdateJenkinDto } from './dto/update-jenkin.dto';
var axios = require('axios');

@Controller('jenkins')
export class JenkinsController {
  constructor(private readonly jenkinsService: JenkinsService) { }

  @Post()
  create(@Body() createJenkinDto: CreateJenkinDto) {

//     const axios = require('axios');

// // const jenkinsUrl = 'http://jenkins-url:8080';
// // const username = 'your_username';
// // const password = 'your_password';

//  const jenkinsUrl = 'http://20.51.249.199:8080';
//     const username = 'admin';
//     const password = 'admin@1093'

// // Fetch the CSRF crumb
// axios.get(`${jenkinsUrl}/crumbIssuer/api/json`, {
//   auth: {
//     username: username,
//     password: password
//   }
// })
// .then(response => {
//   const crumbData = response.data;

//   console.log(crumbData)
//   const headers = {
//     'Jenkins-Crumb': crumbData.crumb,
//     'Content-Type': 'application/json'
//   };

//   console.log(headers)

//   // Your API request
//   axios.post(`http://20.51.249.199:8080/job/TestJob/build`,{
//     headers: headers,
//     auth: {
//       username: username,
//       password: crumbData.crumb
//     }
//   })
//   .then(apiResponse => {
//     console.log('API Response:', apiResponse.data);
//   })
//   .catch(apiError => {
//     console.error('API Error:', apiError.message);
//   });
// })
// .catch(crumbError => {
//   console.error('Error fetching CSRF crumb:', crumbError);
// });


    const jenkinsUrl = 'http://20.51.249.199:8080/job/TestJob/build';
    const userName = 'admin';
    const password = 'admin@1093'

    var config = {
      method: 'POST',
      url: jenkinsUrl,
      headers: {
        Authorization: `Basic ${Buffer.from(`${userName}:${password}`).toString('base64')}`,
        // "Jenkins-Crumb": '72e3947bc8c3d1d076267a46f0eeced43be57a65adab4e19cb522dad0fdef654'
      }
    };

    axios(config)
      .then(function (response) {
        console.log("success")
        console.log(JSON.stringify(response.data));
        return response
      })
      .catch(function (error) {
        console.log(error);
        return error
      });
    // return this.jenkinsService.create(createJenkinDto);
  }

  @Get()
  findAll() {
    return this.jenkinsService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.jenkinsService.findOne(+id);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updateJenkinDto: UpdateJenkinDto) {
    return this.jenkinsService.update(+id, updateJenkinDto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.jenkinsService.remove(+id);
  }
}
