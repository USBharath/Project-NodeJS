import { PartialType } from '@nestjs/swagger';
import { CreateJenkinDto } from './create-jenkin.dto';

export class UpdateJenkinDto extends PartialType(CreateJenkinDto) {}
