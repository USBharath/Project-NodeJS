export class CreateJenkinDto {}
