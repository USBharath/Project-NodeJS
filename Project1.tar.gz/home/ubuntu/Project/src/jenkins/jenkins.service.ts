import { Injectable } from '@nestjs/common';
import { CreateJenkinDto } from './dto/create-jenkin.dto';
import { UpdateJenkinDto } from './dto/update-jenkin.dto';

@Injectable()
export class JenkinsService {
  create(createJenkinDto: CreateJenkinDto) {
    return 'This action adds a new jenkin';
  }

  findAll() {
    return `This action returns all jenkins`;
  }

  findOne(id: number) {
    return `This action returns a #${id} jenkin`;
  }

  update(id: number, updateJenkinDto: UpdateJenkinDto) {
    return `This action updates a #${id} jenkin`;
  }

  remove(id: number) {
    return `This action removes a #${id} jenkin`;
  }
}
