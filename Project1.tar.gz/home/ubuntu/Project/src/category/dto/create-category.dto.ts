import { ApiProperty } from '@nestjs/swagger';
import { IsBoolean, IsNotEmpty, IsString } from '@nestjs/class-validator';

export class CreateCategoryDto {

  @IsString({message : "Category name should be string"})
  @IsNotEmpty({message : "Category name should not be empty"})
  @ApiProperty()
  name: string;

  @IsBoolean({message : "Category name should be boolean"})
  @ApiProperty()
  isActive: boolean;
}
