import { Entity, Column, PrimaryGeneratedColumn, Index } from 'typeorm';
@Entity()
export class Category {
    @PrimaryGeneratedColumn("uuid")
    id: string;
  
    @Index({ fulltext: true })
    @Column()
    name: string;
  
    @Column({ default: true })
    isActive: boolean;
}
