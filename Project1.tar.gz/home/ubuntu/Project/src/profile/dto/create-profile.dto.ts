import { ApiProperty } from '@nestjs/swagger';
import { IsString } from '@nestjs/class-validator';

export class CreateProfileDto {

  @IsString()
  @ApiProperty({example: "Puri"})
  city: string;

  @IsString()
  @ApiProperty({example: "Odisha"})
  state: string;
}

